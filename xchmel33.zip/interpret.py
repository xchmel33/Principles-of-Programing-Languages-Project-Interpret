import sys
import os
from os import path
import xml.etree.ElementTree as ET
from xml.dom.minidom import parse, parseString  # extra library for checking xml version and encoding


# 10 - chybějící parametr skriptu (je-li třeba) nebo použití zakázané kombinace parametrů;
# 11 - chyba při otevírání vstupních souborů (např. neexistence, nedostatečné oprávnění);
# 12 - chyba při otevření výstupních souborů pro zápis (např. nedostatečné oprávnění, chyba při zápisu);
# 31 - chybný XML formát ve vstupním souboru (soubor není tzv. dobře formátovaný, angl. well-formed, viz [1]);
# 32 - neočekávaná struktura XML (např. element pro argument mimo element pro instrukci, instrukce s duplicitním pořadím nebo záporným pořadím) či lexikální nebo
#      syntaktická chyba textových elementů a atributů ve vstupním XML souboru (např. chybný lexém pro číselný nebo řetězcový literál, neznámý operační kód apod.).
# 52 - chyba při sémantických kontrolách vstupního kódu v IPPcode21 (např. použití nedefinovaného návěští, redefinice proměnné);
# 53 - běhová chyba interpretace – špatné typy operandů;
# 54 - běhová chyba interpretace – přístup k neexistující proměnné (rámec existuje);
# 55 - běhová chyba interpretace – rámec neexistuje (např. čtení z prázdného zásobníku rámců);
# 56 - běhová chyba interpretace – chybějící hodnota (v proměnné, na datovém zásobníku nebo v zásobníku volání);
# 57 - běhová chyba interpretace – špatná hodnota operandu (např. dělení nulou, špatná návratová hodnota instrukce EXIT);
# 58 - běhová chyba interpretace – chybná práce s řetězcem.
# 99 - interní chyba (neovlivněná vstupními soubory či parametry příkazové řádky; např. chyba alokace paměti).

class var:
    def __init__(self, name, value, type, frame):
        self.name = name
        self.value = value
        self.type = type
        self.frame = frame


class instr:
    def __init__(self, opcode):
        self.opcode = opcode
        self.args = []

    def add_argument(self, argumentType, argumentValue):
        self.args.append(arg(argumentType, argumentValue))


class arg:
    def __init__(self, argumentType, argumentValue):
        self.type = argumentType
        self.value = argumentValue


# functions checks if file exists and sufficient permisions for reading
def get_file(param):
    x = param.split("=")
    if path.isfile(x[1]) and os.access(x[1], os.R_OK):
        return x[1]
    else:
        exit(11)


# function checks if string represents an integer
def is_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


# symb -> constant or variable
def symb_check(symb):

    frame = symb.value[0:3]
    name = symb.value[3:]

    # variable definition check
    if symb.type == "var":
        if frame == "GF@" and name in GF.keys():
            if GF[name].value == "none":
                exit(56)    # missing value in variable
            else:
                return GF[name]
        elif frame == "LF@" and name in LF.keys():
            if LF[name].value == "none":
                exit(56)    # missing value in variable
            else:
                return LF[name]
        elif frame == "TF@" and name in TF.keys():
            if TF[name].value == "none":
                exit(56)    # missing value in variable
            else:
                return TF[name]
        else:
            exit(54)    # undefined variable

    # matching types check
    elif symb.type == "int" and is_int(symb.value):
        return symb
    elif symb.type == "bool" and (symb.value == "true" or symb.value == "false"):
        return symb
    elif symb.type == "nil" or symb.type == "string":
        return symb
    else:
        exit(53)     # invalid type


def assign_to_var(variable, value):

    frame = variable.value[0:3]
    name = variable.value[3:]

    if frame == "GF@" and name in GF.keys():
        if GF[name].type == "undefined":
            GF[name].value = value.value
            GF[name].type = value.type
        elif GF[name].type  == value.type:
            GF[name].value  = value.value
        else:
            exit(53)    # invalid operand types

    elif frame == "LF@" and name in LF.keys():
        if LF[name].type == "undefined":
            LF[name].value = value.value
            LF[name].type = value.type
        elif LF[name].type == value.type:
            LF[name].value = value.value
        else:
            exit(53)    # invalid operand types

    elif frame == "TF@" and name in TF.keys():
        if TF[name].type == "undefined":
            TF[name].value = value.value
            TF[name].type = value.type
        elif TF[name].type == value.type:
            TF[name].value = value.value
        else:
            exit(53)    # invalid operand types

    else:
        exit(54)    # undefined variable


if __name__ == '__main__':

    # Process arguments
    if sys.argv[1] == "--help":

        # Edit
        print("Usage: interpret.py [--help, --source=file, --input=file]\n"
              "IPPcode21 interpreter reads source file xml code representation\n"
              "and input file with inputs of the program, checks for any semantic\n"
              "or other errors and ")

        # No more arguments after help permitted
        if len(sys.argv) > 2:
            exit(10)
        else:
            exit(0)

    # --input or --input --source parameters
    elif sys.argv[1][0:8] == "--input=":
        inputFile = get_file(sys.argv[1])
        if len(sys.argv) > 2:
            if sys.argv[2][0:9] == "--source=":
                sourceFile = get_file(sys.argv[2])
            else:
                exit(10)

    # --source or --source --input parameters
    elif sys.argv[1][0:9] == "--source=":
        sourceFile = get_file(sys.argv[1])
        if len(sys.argv) > 2:
            if sys.argv[2][0:8] == "--input=":
                inputFile = get_file(sys.argv[2])
            else:
                exit(10)

    # Error: at least one parameter is required
    else:
        exit(10)

    # stdin input in case of missing arguments
    try:
        sourceFile
    except NameError:
        sourceFile = sys.stdin
    try:
        inputFile
    except NameError:
        inputFile = sys.stdin

    # XML well-formed ?

    # XML program representation parsing
    try:
        XMLCode = ET.parse(sourceFile)
    except SyntaxError:
        exit(31)    # XML is not well-formed
    grandparent = XMLCode.getroot()
    if grandparent.tag != "program" or 'language' not in grandparent.attrib.keys() or grandparent.attrib['language'] != "IPPcode21":
        exit(32)    # invalid root tag or program language

    # instructions parsing
    instructions = [0 for x in range(100)]  # array of instructions for sorting by instruction order
    for parent in grandparent:
        if parent.tag != "instruction" or 'order' not in parent.attrib.keys() or not is_int(parent.attrib['order']) or 'opcode' not in parent.attrib.keys():
            exit(32)    # invalid instruction name or missing order or opcode
        else:

            # create instruction at index defined by order
            index = int(parent.attrib['order'])
            if instructions[index] != 0:
                exit(32)    # duplicate instruction order
            else:
                instructions[index] = instr(parent.attrib['opcode'])

            # argument parsing
            for child in parent:
                if child.tag[0:3] != "arg" or 'type' not in child.attrib.keys():
                    exit(32)    # invalid argument name or missing type
                else:
                    instructions[index].add_argument(child.attrib['type'], child.text)

    # remove empty instructions
    instructions = list(filter((0).__ne__, instructions))

    # print
    # for instruction in instructions:
    #     print(instruction.opcode, end=" ")
    #     for argument in instruction.args:
    #         print(argument.type + " " + argument.value)

    # IPPcode21 interpreter
    GF = {}
    LF = {} # implement as stack
    TF = {}
    for inst in instructions:

        name = inst.opcode.upper()
        argCount = len(inst.args)

        if name == "MOVE":
            if argCount != 2:
                exit(32)    # insufficient amount of arguments in XML
            else:
                assign_to_var(inst.args[0], symb_check(inst.args[1]))

        elif name == "CREATEFRAME":
            exit(0)

        elif name == "PUSHFRAME":
            exit(0)

        elif name == "POPFRAME":
            exit(0)

        elif name == "DEFVAR":
            if argCount != 1 or inst.args[0].type != "var":
                exit(32)    # insufficient amount of arguments or invalid type in XML

            # arg -> var
            name = inst.args[0].value[3:]
            frame = inst.args[0].value[0:3]
            variable = var(name, "none", "undefined", frame)

            # append matching frame
            if frame == "GF@":
                GF[name] = variable
            elif frame == "LF@":
                LF[name] = variable
            elif frame == "TF@":
                TF[name] = variable
            else:
                exit(1)     # invalid frame

        elif name == "CALL":
            exit(0)

        elif name == "RETURN":
            exit(0)

        elif name == "PUSHS":
            exit(0)

        elif name == "POPS":
            exit(0)

        elif name == "ADD":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "int" or symb2.type != "int":
                exit(53)    # invalid types

            # calculate and assign
            symb1.value = int(symb1.value) + int(symb2.value)
            assign_to_var(inst.args[0], symb1)

        elif name == "SUB":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "int" or symb2.type != "int":
                exit(53)    # invalid types

            # calculate and assign
            symb1.value = int(symb1.value) - int(symb2.value)
            assign_to_var(inst.args[0], symb1)

        elif name == "MUL":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "int" or symb2.type != "int":
                exit(53)    # invalid types

            # calculate and assign
            symb1.value = int(symb1.value) * int(symb2.value)
            assign_to_var(inst.args[0], symb1)

        elif name == "IDIV":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "int" or symb2.type != "int":
                exit(53)    # invalid types

            if symb2.value == 0:
                exit(57)    # zero division

            # calculate and assign
            symb1.value = int(symb1.value) / int(symb2.value)
            assign_to_var(inst.args[0], symb1)

        elif name == "LT":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb2.type != symb1.type:
                exit(53)    # invalid types

            # comparison for different types
            if symb1.type == "int":
                if int(symb1.value) < int(symb2.value):
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            elif symb1.type == "bool":
                if symb1.value == "false" and symb2.value == "true":
                    symb1.value = "true"
            elif symb1.type == "string":
                if symb1.value < symb2.value:
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            else:
                exit(53)    # invalid types

            # assign result of type bool
            symb1.type = "bool"
            assign_to_var(inst.args[0], symb1)

        elif name == "GT":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb2.type != symb1.type:
                exit(53)    # invalid types

            # comparison for different types
            if symb1.type == "int":
                if int(symb1.value) > int(symb2.value):
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            elif symb1.type == "bool":
                if not (symb1.value == "true" and symb2.value == "false"):
                    symb1.value = "false"
            elif symb1.type == "string":
                if symb1.value > symb2.value:
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            else:
                exit(53)    # invalid types

            # assign result of type bool
            symb1.type = "bool"
            assign_to_var(inst.args[0], symb1)

        elif name == "EQ":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb2.type != symb1.type:
                exit(53)    # invalid types

            # comparison for different types
            if symb1.type == "int":
                if int(symb1.value) == int(symb2.value):
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            elif symb1.type in ["bool", "string"]:
                if symb1.value == symb2.value:
                    symb1.value = "true"
                else:
                    symb1.value = "false"
            else:
                exit(53)    # invalid types

            # assign result of type bool
            symb1.type = "bool"
            assign_to_var(inst.args[0], symb1)

        elif name == "AND":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "bool" or symb2.type != symb1.type:
                exit(53)    # invalid types

            # unless both symb values are true assign false else true
            if not (symb1.value == symb2.value and symb1.value == "true"):
                symb1.value = "false"
            assign_to_var(inst.args[0], symb1)

        elif name == "OR":
            if argCount != 3:
                exit(32)    # insufficient amount of arguments in XML

            # symbs semantic validation
            symb1 = symb_check(inst.args[1])
            symb2 = symb_check(inst.args[2])
            if symb1.type != "bool" or symb2.type != symb1.type:
                exit(53)    # invalid types

            # if at least one symb value is true assign true else false
            if symb1.value == "true" or symb2.value == "true":
                symb1.value = "true"
            else:
                symb1.value = "false"
            assign_to_var(inst.args[0], symb1)

        elif name == "NOT":
            if argCount != 2:
                exit(32)    # insufficient amount of arguments in XML

            # symb semantic validation
            symb = symb_check(inst.args[1])
            if symb.type != "bool":
                exit(53)    # invalid types

            # negate symb value
            if symb.value == "true":
                symb.value = "false"
            else:
                symb.value = "true"

            # assign result of type bool
            assign_to_var(inst.args[0], symb)

        elif name == "INT2CHAR":
            if argCount != 2:
                exit(32)    # insufficient amount of arguments in XML

            # symb semantic validation
            symb = symb_check(inst.args[0])

            if symb.type != "int":
                exit(53)    # invalid types

            # convert int to Unicode character
            try:
                symb.value = chr(int(symb.value))
            except ValueError or NameError:
                exit(58)

            # assign result of type string
            symb.type = "string"
            assign_to_var(inst.args[0], symb)

        elif name == "STRI2INT":
            exit(0)

        elif name == "READ":
            exit(0)

        elif name == "WRITE":
            if argCount != 1:
                exit(32)    # invalid number of arguments

            # write to stdout
            print(symb_check(inst.args[0]).value)

        elif name == "CONCAT":
            exit(0)

        elif name == "STRLEN":
            exit(0)

        elif name == "GETCHAR":
            exit(0)

        elif name == "SETCHAR":
            exit(0)

        elif name == "TYPE":
            exit(0)

        elif name == "LABEL":
            exit(0)

        elif name == "JUMP":
            exit(0)

        elif name == "JUMPIFEQ":
            exit(0)

        elif name == "JUMPIFNEQ":
            exit(0)

        elif name == "EXIT":
            exit(0)

        elif name == "DPRINT":
            exit(0)

        elif name == "BREAK":
            exit(0)

        else:
            exit(32)    # invalid instruction opcode in XML
